/*
 * Carware_final2_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Carware_final2".
 *
 * Model version              : 4.4
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C source code generated on : Mon Nov 27 14:49:37 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Carware_final2_types_h_
#define RTW_HEADER_Carware_final2_types_h_

/* Parameters (default storage) */
typedef struct P_Carware_final2_T_ P_Carware_final2_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Carware_final2_T RT_MODEL_Carware_final2_T;

#endif                                 /* RTW_HEADER_Carware_final2_types_h_ */
